<?php
$channelAccessToken = 'rlxJdR+9qb0tXxJqPHMMcJxs3W07TZz2LCbW/tinlQls6JbkKzmZ7TqbqCFv33L10pq294pKbfUYR7pKp7ENvd1lcj8pRFic0frU3bF4ih+cZTC9lKCsRsKdpOyk4rJdUA2Zu2G3Ax3M3FKLwaUZiAdB04t89/1O/w1cDnyilFU=';
$channelSecret = '8d08cfd28bb41de82ae7383c34d00818';
$userId = 'U6004d4a6ee7645aa61f240f0bd5ecc48'; // Fion 的
$groupIdHey = 'Cfe5d5b0b983b49f7110f25132b494d56'; // 嘿 測試的群組
$groupIdSlaq = 'C9470388ec8dd2fe9131f87451df71e6e'; // 教會的群組
$groupIdLdtSlaqElder = 'C00c025bc6caebbb24c72784993bbb005'; // 文健站
$groupIdLdtJoyce = 'Ca0f788e22237e6a381033105b8dd8325'; // 小潘的那個群組
$groupIdReadBible = 'Cc5a531476ffde35fd5030ca51bf25294'; // 讀經群組
